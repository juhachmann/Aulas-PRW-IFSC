<?php

    require "../includes/banco/dados-conexao.inc.php";
    require "../includes/banco/conectar.inc.php";
    require "../includes/banco/definir-utf8.inc.php";
    require "../includes/banco/criar-banco.inc.php";
    require "../includes/banco/abrir-banco.inc.php";
    require "../includes/banco/criar-tabela.inc.php";

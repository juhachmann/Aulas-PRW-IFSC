<?php
 $conexao->select_db($nomeDoBanco) or exit($conexao->error);
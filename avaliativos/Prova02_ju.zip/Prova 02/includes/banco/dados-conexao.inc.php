<?php
 $servidor = "localhost"; //ou 127.0.0.1
 $usuario  = "root";
 $senha    = "";

 $nomeDoBanco  = "cbf_ju";
 $tabelaTimes = "times";
 
<?php

    require "../includes/componentes/navbar.php";

    require "../includes/busca-todos.inc.php";

    require "../includes/componentes/tabela.php";

    require "../includes/desconectar.inc.php";


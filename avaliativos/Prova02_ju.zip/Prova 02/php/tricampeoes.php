<?php

    require "../includes/componentes/navbar.php";

    require "../includes/busca-tri.inc.php";

    require "../includes/componentes/tabela.php";

    require "../includes/desconectar.inc.php";
